from parallel.events.event import Event


class StopEvent(Event):
    """Остановка диспетчера задач"""
    ...
