from parallel.events.event import Event


class TaskFinishedEvent(Event):
    """Событие завершения создания задач"""
    ...
