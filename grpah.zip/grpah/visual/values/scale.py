linear = 'linear'
log = 'log'
