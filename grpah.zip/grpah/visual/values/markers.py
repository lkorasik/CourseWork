star = '*'
point = '.'
nothing = ','
