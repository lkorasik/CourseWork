from sympy import Symbol

a = Symbol("\\alpha")
b = Symbol("\\beta")
x = Symbol("x")
eta = Symbol("\\eta")
